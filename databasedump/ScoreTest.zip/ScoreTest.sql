drop database if exists bunnyDB;
create database bunnyDB;
use bunnyDB;

create table bunnyDB.`user` (
	user_id int primary key auto_increment,
	`name` varchar(50),
    `password` varchar(50)
);

create table bunnyDB.score (
	score_id int primary key auto_increment,
    score int,
    user_id int,
    foreign key(user_id)
		references bunnyDB.`user`(user_id)
);

insert into bunnyDB.`user`(`name`,`password`) values 
	("fabian", "123"),
    ("djani","hallo"),
    ("jasi","test");

insert into bunnyDb.score (score, user_id) values 
	(5, 1),
    (15, 1),
    (10, 2),
    (25, 3);